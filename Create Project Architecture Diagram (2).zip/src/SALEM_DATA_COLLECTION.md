# Salem Bus Data Collection Guide

This guide provides everything you need to collect complete, authoritative data for Salem's public transport system (TNSTC Salem).

## Table of Contents

1. [Data Schema](#data-schema)
2. [Data Sources](#data-sources)
3. [Collection Methods](#collection-methods)
4. [Python Scripts](#python-scripts)
5. [CSV Templates](#csv-templates)
6. [Integration Steps](#integration-steps)

## Data Schema

### 1. Routes Table (`routes.csv`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| route_id | string | Yes | Unique route identifier (e.g., "5", "72", "Y1") |
| name | string | Yes | Route name (e.g., "City Bus Stand - Kannankurichi") |
| operator | string | Yes | "TNSTC Salem" |
| origin | string | Yes | Starting point |
| destination | string | Yes | End point |
| via_notes | string | No | Key stops along the route |
| route_type | string | Yes | "city", "mofussil", "express", or "ghat" |
| frequency | string | No | Service frequency (e.g., "Every 15 minutes") |
| depot | string | No | Operating depot |
| active | boolean | No | Whether route is currently operational |
| last_verified | date | No | Last verification date |

### 2. Stops Table (`stops.csv`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| stop_id | string | Yes | Unique identifier (e.g., "SALM_STOP_001") |
| stop_name | string | Yes | Official stop name |
| lat | float | Yes | Latitude (decimal degrees) |
| lon | float | Yes | Longitude (decimal degrees) |
| zone | string | No | Municipal zone/ward |
| tags | string | No | Comma-separated (e.g., "shelter,bench,terminal") |
| wheelchair | boolean | No | Wheelchair accessibility |
| last_verified | date | No | Last verification date |

### 3. Route-Stop Sequence Table (`route_stop_sequence.csv`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| route_id | string | Yes | Links to routes.route_id |
| stop_sequence | int | Yes | Order number (1, 2, 3...) |
| stop_id | string | Yes | Links to stops.stop_id |
| arrival_time_template | string | No | Expected arrival time if timetable exists |
| distance_from_origin_m | int | No | Distance in meters from origin |
| direction | string | No | "outbound" or "inbound" |
| note | string | No | Special instructions |

## Data Sources

### Official Government Sources

1. **Salem District Transport Department**
   - URL: https://salem.nic.in/departments/transport-department/
   - Contains: Timetables, route lists, mofussil routes, ghat road schedules
   - Action: Download PDFs and HTML pages, parse tables

2. **TNSTC Salem Official**
   - URL: https://www.tnstc.in
   - Look for: Salem division PDFs, fleet information, depot details
   - Contains: Historical data, fleet sizes, official route brochures

3. **Tamil Nadu Transport Department**
   - Portal for permits, route approvals
   - Contact local office for current fleet numbers

### Community & Crowdsourced Data

4. **TNSTC Enthusiast Communities**
   - Example: https://tnstcinfo.wordpress.com
   - Useful for: Route numbers, depot assignments, unofficial route maps
   - Warning: Verify all data against official sources

5. **OpenStreetMap (OSM)**
   - Use Overpass API to extract existing bus stops and routes
   - Many contributors have mapped Salem's transport
   - See Python script below for automated extraction

### Field Collection

6. **GPS Tracking**
   - Apps: OSMTracker, GPX Logger, Geo Tracker
   - Method: Ride each route with GPS running
   - Records: Actual route paths, stop locations, timing data

7. **Driver & Local Verification**
   - Interview bus drivers for stop names and sequence
   - Verify with depot managers for accurate route information
   - Cross-check with passengers for commonly used stop names

## Collection Methods

### Phase 1: Web Scraping (Automated)

```python
# Use the provided tnstc_scrape.py script
python tnstc_scrape.py
```

This will:
- Download route PDFs from salem.nic.in
- Extract tables using tabula-py
- Generate initial routes.csv

### Phase 2: OSM Data Extraction

```bash
# Run Overpass query (see overpass_query.py)
python overpass_query.py --bbox "11.60,78.10,11.80,78.25" --output salem_osm_stops.geojson
```

Extract bus stops within Salem bounds from OpenStreetMap.

### Phase 3: Field Survey

1. **Prepare:**
   - Install GPS tracking app on mobile
   - Print preliminary stop lists for verification
   - Prepare data collection forms

2. **Execute:**
   - Ride each major route
   - Record GPS coordinates at each stop
   - Note stop names, shelters, accessibility
   - Take photos for documentation

3. **Process:**
   - Export GPS traces as GPX
   - Convert to CSV using provided scripts
   - Merge with OSM data

### Phase 4: Validation & Cross-Check

1. Compare web-scraped routes with field data
2. Verify stop coordinates on satellite imagery
3. Cross-check route numbers with TNSTC depot
4. Validate with local passengers/drivers

## Python Scripts

### 1. TNSTC Web Scraper

```python
# File: scripts/tnstc_scrape.py
import requests
from bs4 import BeautifulSoup
import csv
import time

BASE = "https://salem.nic.in"

def fetch_page(url):
    r = requests.get(url, timeout=20)
    r.raise_for_status()
    return BeautifulSoup(r.text, "html.parser")

def get_moffusil_routes():
    url = f"{BASE}/departments/transport-department/"
    soup = fetch_page(url)
    links = []
    for a in soup.find_all("a"):
        href = a.get("href", "")
        if "moffusil" in (a.text.lower() + href.lower()):
            links.append(href if href.startswith("http") else BASE + href)
    return links

def download_pdf(url, filename):
    r = requests.get(url)
    open(filename, "wb").write(r.content)
    print(f"Downloaded: {filename}")

if __name__ == "__main__":
    print("Fetching transport data...")
    links = get_moffusil_routes()
    for i, link in enumerate(links):
        if link.endswith(".pdf"):
            download_pdf(link, f"salem_route_{i}.pdf")
        time.sleep(1)  # Be polite to the server
```

### 2. CSV to GeoJSON Converter

```python
# File: scripts/csv_to_geojson.py
import csv
import json
from collections import defaultdict

def convert_to_geojson(stops_csv, sequences_csv, output_file):
    # Load stops
    stops = {}
    with open(stops_csv, newline='') as f:
        reader = csv.DictReader(f)
        for r in reader:
            stops[r['stop_id']] = {
                'name': r['stop_name'],
                'lat': float(r['lat']),
                'lon': float(r['lon'])
            }

    # Load route sequences
    routes = defaultdict(list)
    with open(sequences_csv, newline='') as f:
        reader = csv.DictReader(f)
        for r in reader:
            routes[r['route_id']].append((int(r['stop_sequence']), r['stop_id']))

    # Build GeoJSON
    features = []
    for route_id, seq in routes.items():
        seq_sorted = sorted(seq, key=lambda x: x[0])
        coords = []
        
        for _, stop_id in seq_sorted:
            s = stops.get(stop_id)
            if s:
                coords.append([s['lon'], s['lat']])
                # Add stop point feature
                features.append({
                    "type": "Feature",
                    "properties": {
                        "type": "stop",
                        "stop_id": stop_id,
                        "stop_name": s['name'],
                        "route_id": route_id
                    },
                    "geometry": {
                        "type": "Point",
                        "coordinates": [s['lon'], s['lat']]
                    }
                })
        
        # Add route line feature
        if coords:
            features.append({
                "type": "Feature",
                "properties": {
                    "type": "route",
                    "route_id": route_id
                },
                "geometry": {
                    "type": "LineString",
                    "coordinates": coords
                }
            })

    geojson = {"type": "FeatureCollection", "features": features}
    
    with open(output_file, 'w') as f:
        json.dump(geojson, f, indent=2)
    
    print(f"Wrote {output_file}")

if __name__ == "__main__":
    convert_to_geojson('stops.csv', 'route_stop_sequence.csv', 'salem_routes.geojson')
```

### 3. Overpass API Query

```python
# File: scripts/overpass_query.py
import requests
import json
import argparse

def query_overpass(bbox, output_file):
    """
    Query Overpass API for bus stops in Salem
    bbox format: "min_lat,min_lon,max_lat,max_lon"
    """
    overpass_url = "https://overpass-api.de/api/interpreter"
    
    query = f"""
    [out:json][timeout:60];
    (
      node["highway"="bus_stop"]({bbox});
      relation["type"="route"]["route"="bus"]({bbox});
    );
    out body;
    >;
    out skel qt;
    """
    
    response = requests.post(overpass_url, data={'data': query})
    
    if response.status_code == 200:
        data = response.json()
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Downloaded {len(data.get('elements', []))} elements to {output_file}")
    else:
        print(f"Error: {response.status_code}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--bbox', default='11.60,78.10,11.80,78.25', 
                        help='Bounding box: min_lat,min_lon,max_lat,max_lon')
    parser.add_argument('--output', default='salem_osm_data.json')
    args = parser.parse_args()
    
    query_overpass(args.bbox, args.output)
```

## CSV Templates

Download these templates from the Data Importer in your app, or create manually:

### routes.csv
```csv
route_id,name,operator,origin,destination,route_type,depot,last_verified
5,City Bus Stand - Kannankurichi,TNSTC Salem,Salem Central Bus Stand,Kannankurichi,city,Erumapalayam Depot,2025-10-21
72,City Bus Stand - Parappatti,TNSTC Salem,Salem Central Bus Stand,Parappatti,city,Vazhapadi Depot,2025-10-21
```

### stops.csv
```csv
stop_id,stop_name,lat,lon,zone,last_verified
SALM_STOP_001,Salem Central Bus Stand,11.6643,78.1460,Suramangalam,2025-10-21
SALM_STOP_002,Kannankurichi Bus Stop,11.6595,78.1502,Kannankurichi,2025-10-21
```

### route_stop_sequence.csv
```csv
route_id,stop_sequence,stop_id
5,1,SALM_STOP_001
5,2,SALM_STOP_002
72,1,SALM_STOP_001
72,2,SALM_STOP_003
```

## Integration Steps

### Step 1: Initial Setup
1. Create a `data/salem` directory in your project
2. Copy Python scripts to `scripts/` directory
3. Install dependencies: `pip install requests beautifulsoup4 tabula-py`

### Step 2: Collect Data
1. Run web scraper for official routes
2. Run Overpass query for OSM stops
3. Manually verify and merge data
4. Conduct field surveys for missing data

### Step 3: Import to Application
1. Open Data Importer (Admin panel)
2. Upload routes.csv
3. Upload stops.csv
4. Upload route_stop_sequence.csv
5. Verify on map view

### Step 4: Supabase Integration
The data will be stored in Supabase KV store with these endpoints:

```typescript
// Store routes
await supabase.kv.set('salem_routes', routesData);

// Store stops
await supabase.kv.set('salem_stops', stopsData);

// Store sequences
await supabase.kv.set('salem_sequences', sequencesData);
```

### Step 5: Real-time Updates
1. Set up bus GPS tracking (hardware or mobile app)
2. Stream positions to Supabase Realtime
3. Update bus locations every 10-30 seconds
4. Display live positions on map

## Fleet Information

### Salem TNSTC Depots:
- Erumapalayam Depot
- Vazhapadi Depot
- Salem Town Depot
- Yercaud Depot
- Attur Depot
- Sankagiri Depot

### Estimated Fleet Size:
Contact TNSTC Salem regional office for current fleet numbers.
Historical data suggests 400-600 buses across Salem division.

## Next Actions

1. **Immediate**: Download CSV templates and start filling with known routes
2. **This Week**: Run Python scraper on salem.nic.in
3. **This Month**: Conduct field surveys for top 10 routes
4. **Ongoing**: Verify and update data quarterly

## Support Resources

- **TNSTC Salem Contact**: Check salem.nic.in for phone/email
- **OSM Community**: https://www.openstreetmap.org/
- **Transport Department**: Visit local office for official data requests

## Notes

- Always verify coordinates using satellite imagery (Google Maps, OSM)
- Stop names may vary - use official TNSTC names as primary
- GPS traces may need map-matching to roads
- Some routes may be seasonal or have varying schedules
- Ghat routes (like Yercaud) have special considerations

---

**Last Updated**: October 21, 2025
**Version**: 1.0
**Maintained by**: Salem Smart Transport Team
