import React, { useEffect, useRef } from 'react';
import { Bus, Route } from '../types';
import { Badge } from './ui/badge';
import { MapPin, Navigation } from 'lucide-react';
import L from 'leaflet@1.9.4';

interface MapViewProps {
  buses: Bus[];
  routes: Route[];
  selectedBus: string | null;
  onBusSelect: (busId: string) => void;
}

export const MapView: React.FC<MapViewProps> = ({ buses, routes, selectedBus, onBusSelect }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const routeLayersRef = useRef<L.LayerGroup | null>(null);

  // Map center (Salem area - TNSTC Salem coverage)
  const mapCenter: [number, number] = [11.65, 78.15];

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Fix Leaflet default icon paths issue
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    });

    // Create map instance with satellite view
    const map = L.map(mapRef.current).setView(mapCenter, 13);

    // Add Esri World Imagery (satellite) tile layer
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
      maxZoom: 18,
    }).addTo(map);

    // Add labels overlay for better readability
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    // Create layer group for routes
    routeLayersRef.current = L.layerGroup().addTo(map);

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Draw routes
  useEffect(() => {
    if (!mapInstanceRef.current || !routeLayersRef.current) return;

    const routeLayer = routeLayersRef.current;
    routeLayer.clearLayers();

    routes.forEach((route) => {
      // Draw route polyline
      const routeCoords: [number, number][] = route.stops.map(stop => [stop.latitude, stop.longitude]);
      const polyline = L.polyline(routeCoords, {
        color: route.color,
        weight: 3,
        opacity: 0.7,
        dashArray: '10, 10',
      }).addTo(routeLayer);

      // Add popup to polyline
      polyline.bindPopup(`<b>Route ${route.routeNumber}</b><br/>${route.routeName}`);

      // Draw stops
      route.stops.forEach((stop, idx) => {
        const stopIcon = L.divIcon({
          className: 'custom-stop-marker',
          html: `<div style="
            width: 12px;
            height: 12px;
            background: white;
            border: 2px solid ${route.color};
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          "></div>`,
          iconSize: [12, 12],
          iconAnchor: [6, 6],
        });

        const marker = L.marker([stop.latitude, stop.longitude], { icon: stopIcon }).addTo(routeLayer);
        marker.bindPopup(`<b>${stop.name}</b><br/>Stop ${idx + 1} on Route ${route.routeNumber}`);
      });
    });
  }, [routes]);

  // Update bus markers
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    const map = mapInstanceRef.current;
    const currentMarkers = markersRef.current;
    const newBusIds = new Set(buses.map(b => b.bus_id));

    // Remove markers for buses that no longer exist
    currentMarkers.forEach((marker, busId) => {
      if (!newBusIds.has(busId)) {
        marker.remove();
        currentMarkers.delete(busId);
      }
    });

    // Add/update markers for all buses
    buses.forEach((bus) => {
      const isSelected = selectedBus === bus.bus_id;
      const statusColor = bus.current_status === 'Running' ? '#10b981' :
                          bus.current_status === 'Delayed' ? '#f59e0b' :
                          bus.current_status === 'Maintenance' ? '#ef4444' : '#6b7280';

      const busIcon = L.divIcon({
        className: 'custom-bus-marker',
        html: `<div style="
          position: relative;
          width: 32px;
          height: 32px;
        ">
          ${isSelected ? `<div style="
            position: absolute;
            top: -4px;
            left: -4px;
            width: 40px;
            height: 40px;
            border: 2px solid rgba(59, 130, 246, 0.5);
            border-radius: 50%;
            animation: pulse 2s infinite;
          "></div>` : ''}
          <div style="
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 0;
            border-left: 16px solid transparent;
            border-right: 16px solid transparent;
            border-bottom: 28px solid ${statusColor};
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
          "></div>
          <div style="
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 0;
            border-left: 14px solid transparent;
            border-right: 14px solid transparent;
            border-bottom: 25px solid ${statusColor};
            border: 2px solid white;
            margin: 1px;
          "></div>
          <span style="
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            font-size: 10px;
            font-weight: bold;
          ">${bus.route_number}</span>
        </div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 28],
      });

      let marker = currentMarkers.get(bus.bus_id);
      if (marker) {
        // Update existing marker
        marker.setLatLng([bus.latitude, bus.longitude]);
        marker.setIcon(busIcon);
      } else {
        // Create new marker
        marker = L.marker([bus.latitude, bus.longitude], { icon: busIcon }).addTo(map);
        marker.on('click', () => onBusSelect(bus.bus_id));
        currentMarkers.set(bus.bus_id, marker);
      }

      // Update popup
      marker.bindPopup(`
        <div style="min-width: 150px;">
          <b>Bus ${bus.route_number}</b><br/>
          Status: <span style="color: ${statusColor};">${bus.current_status}</span><br/>
          Seats Available: ${bus.seats_available}/${bus.total_seats}<br/>
          Speed: ${bus.speed} km/h
        </div>
      `);

      // Auto-open popup for selected bus
      if (isSelected) {
        marker.openPopup();
      }
    });
  }, [buses, selectedBus, onBusSelect]);

  return (
    <div className="relative w-full h-full bg-gray-50 rounded-lg overflow-hidden border border-gray-200">
      <div ref={mapRef} className="w-full h-full" />
      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg z-[1000]">
        <div className="flex flex-col gap-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Running</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
            <span>Delayed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span>Maintenance</span>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.5;
            transform: scale(1.1);
          }
        }
        .leaflet-container {
          font-family: inherit;
        }
        .custom-bus-marker,
        .custom-stop-marker {
          background: transparent;
          border: none;
        }
      `}</style>
    </div>
  );
};
