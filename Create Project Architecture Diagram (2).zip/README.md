
  # Create Project Architecture Diagram

  This is a code bundle for Create Project Architecture Diagram. The original project is available at https://www.figma.com/design/ZVKrJ9O36DZckqtjlz8G5j/Create-Project-Architecture-Diagram.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  