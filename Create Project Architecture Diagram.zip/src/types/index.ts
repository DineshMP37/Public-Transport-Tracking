export interface Bus {
  bus_id: string;
  route_number: string;
  driver_id: string;
  driver_name: string;
  current_status: 'Running' | 'Delayed' | 'Maintenance' | 'Stopped';
  capacity: number;
  current_occupancy: number;
  latitude: number;
  longitude: number;
  speed: number;
  lastUpdated: Date;
}

export interface Route {
  route_id: string;
  route_name: string;
  route_number: string;
  start_point: string;
  end_point: string;
  stops: Stop[];
  color: string;
}

export interface Stop {
  stop_id: string;
  name: string;
  latitude: number;
  longitude: number;
  order: number;
}

export interface User {
  user_id: string;
  name: string;
  email: string;
  role: 'admin' | 'driver' | 'passenger';
}

export interface LocationUpdate {
  bus_id: string;
  latitude: number;
  longitude: number;
  timestamp: Date;
  speed: number;
}

export interface Notification {
  id: string;
  type: 'delay' | 'breakdown' | 'route-change' | 'info';
  message: string;
  bus_id: string;
  timestamp: Date;
}
