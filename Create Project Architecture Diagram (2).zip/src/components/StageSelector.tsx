import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Navigation, IndianRupee, ArrowRight } from 'lucide-react';
import { calculateStageFare, getStageName, salemFareMatrices } from '../data/salemRoutesData';
import { Alert, AlertDescription } from './ui/alert';

interface StageSelectorProps {
  routeId: string;
  routeNumber: string;
  onStageSelect: (fromStage: number, toStage: number, fare: number) => void;
}

export const StageSelector: React.FC<StageSelectorProps> = ({
  routeId,
  routeNumber,
  onStageSelect,
}) => {
  const [fromStage, setFromStage] = useState<number | null>(null);
  const [toStage, setToStage] = useState<number | null>(null);
  const [fare, setFare] = useState<number>(0);

  const fareMatrix = salemFareMatrices.find(fm => fm.route_id === routeId);

  useEffect(() => {
    if (fromStage !== null && toStage !== null) {
      const calculatedFare = calculateStageFare(routeId, fromStage, toStage);
      setFare(calculatedFare);
    } else {
      setFare(0);
    }
  }, [fromStage, toStage, routeId]);

  const handleStageClick = (stageNumber: number) => {
    if (fromStage === null) {
      setFromStage(stageNumber);
      setToStage(null);
    } else if (toStage === null) {
      if (stageNumber === fromStage) {
        // Clicked same stage, reset
        setFromStage(null);
        setToStage(null);
      } else if (stageNumber > fromStage) {
        setToStage(stageNumber);
      } else {
        // Reverse selection
        setToStage(fromStage);
        setFromStage(stageNumber);
      }
    } else {
      // Reset and start new selection
      setFromStage(stageNumber);
      setToStage(null);
    }
  };

  const handleConfirm = () => {
    if (fromStage !== null && toStage !== null && fare > 0) {
      onStageSelect(fromStage, toStage, fare);
    }
  };

  if (!fareMatrix) {
    return (
      <Alert>
        <AlertDescription>
          Stage information not available for Route {routeNumber}
        </AlertDescription>
      </Alert>
    );
  }

  const isStageInRange = (stageNum: number) => {
    if (fromStage === null || toStage === null) return false;
    const min = Math.min(fromStage, toStage);
    const max = Math.max(fromStage, toStage);
    return stageNum >= min && stageNum <= max;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Journey Stages - Route {routeNumber}</CardTitle>
        <CardDescription>
          Click to select boarding stage, then click destination stage
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Instructions */}
        <div className="bg-blue-50 p-3 rounded-lg">
          <p className="text-sm text-blue-900">
            {fromStage === null && '1. Select your boarding stage'}
            {fromStage !== null && toStage === null && '2. Select your destination stage'}
            {fromStage !== null && toStage !== null && '3. Confirm your selection'}
          </p>
        </div>

        {/* Stage List */}
        <div className="space-y-2">
          {fareMatrix.stages.map((stage, idx) => {
            const isFrom = stage.stage_number === fromStage;
            const isTo = stage.stage_number === toStage;
            const inRange = isStageInRange(stage.stage_number);
            
            return (
              <button
                key={stage.stage_number}
                onClick={() => handleStageClick(stage.stage_number)}
                className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                  isFrom
                    ? 'border-green-500 bg-green-50'
                    : isTo
                    ? 'border-blue-500 bg-blue-50'
                    : inRange
                    ? 'border-gray-300 bg-gray-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isFrom ? 'bg-green-500 text-white' :
                      isTo ? 'bg-blue-500 text-white' :
                      inRange ? 'bg-gray-400 text-white' :
                      'bg-gray-200 text-gray-600'
                    }`}>
                      {stage.stage_number}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>{stage.stage_name}</span>
                      </div>
                      <span className="text-sm text-gray-500">
                        {stage.distance_km} km from origin
                      </span>
                    </div>
                  </div>
                  {isFrom && (
                    <Badge variant="default" className="bg-green-500">
                      Boarding
                    </Badge>
                  )}
                  {isTo && (
                    <Badge variant="default" className="bg-blue-500">
                      Destination
                    </Badge>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Fare Calculation Display */}
        {fromStage !== null && toStage !== null && (
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardContent className="pt-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-green-600" />
                    <span>{getStageName(routeId, fromStage)}</span>
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-400" />
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <span>{getStageName(routeId, toStage)}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-purple-200">
                  <span className="text-sm text-gray-600">
                    {Math.abs(toStage - fromStage)} stages • {
                      Math.abs(
                        fareMatrix.stages.find(s => s.stage_number === toStage)!.distance_km -
                        fareMatrix.stages.find(s => s.stage_number === fromStage)!.distance_km
                      ).toFixed(1)
                    } km
                  </span>
                  <div className="flex items-center gap-1">
                    <IndianRupee className="w-5 h-5 text-purple-600" />
                    <span className="text-2xl text-purple-600">
                      {fare.toFixed(2)}
                    </span>
                  </div>
                </div>

                <Button 
                  onClick={handleConfirm} 
                  className="w-full"
                  size="lg"
                >
                  Confirm Journey & Continue to Seat Selection
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Fare Information */}
        <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600">
          <p>Base Fare: ₹{fareMatrix.base_fare} | Per Stage: ₹{fareMatrix.fare_per_stage}</p>
          {fareMatrix.fare_per_km && (
            <p>Per Kilometer: ₹{fareMatrix.fare_per_km}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
