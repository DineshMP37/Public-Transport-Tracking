import { Route, Stop, MofussilRoute, FareMatrix, FareStage } from '../types';

// Real Salem Mofussil Routes (from TNSTC Salem "List of Mofussil Routes")
export const salemMofussilRoutes: MofussilRoute[] = [
  {
    sl_no: 1,
    route_number: '211A',
    from_to: 'Alangayam - Bangalore',
    via: 'Via Vaniyampadi',
    services: 2,
    journey_time: '5:00',
    fare: 78.00,
    distance_km: 156,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 2,
    route_number: '297B',
    from_to: 'Anchetty - Salem',
    via: 'Via Denkanikotta',
    services: 1,
    journey_time: '5:30',
    fare: 48.00,
    distance_km: 96,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 3,
    route_number: '1062',
    from_to: 'Attur - Chennai',
    via: 'Via Villupuram',
    services: 2,
    journey_time: '6:45',
    fare: 90.00,
    distance_km: 270,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 4,
    route_number: '1029A',
    from_to: 'Attur - Gudiyatham',
    via: 'Via Kallakurichy',
    services: 1,
    journey_time: '6:50',
    fare: 64.00,
    distance_km: 205,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 5,
    route_number: '1200',
    from_to: 'Attur - Mettur',
    via: 'Via R. Puram',
    services: 1,
    journey_time: '4:30',
    fare: 36.00,
    distance_km: 90,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 6,
    route_number: '1066',
    from_to: 'Attur - Pagudupattu',
    via: undefined,
    services: 1,
    journey_time: '1:45',
    fare: 15.50,
    distance_km: 35,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 7,
    route_number: '1118',
    from_to: 'Attur - Ramanatham',
    via: undefined,
    services: 1,
    journey_time: '2:30',
    fare: 20.50,
    distance_km: 50,
    operator: 'TNSTC-Salem'
  },
  // Salem City routes (town service)
  {
    sl_no: 8,
    route_number: '5',
    from_to: 'Salem New Bus Stand - Sankari',
    via: 'Via Ammapet, Gugai',
    services: 12,
    journey_time: '1:15',
    fare: 18.00,
    distance_km: 35,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 9,
    route_number: '72',
    from_to: 'Salem New Bus Stand - Attur',
    via: 'Via Omalur, Thalaivasal',
    services: 8,
    journey_time: '2:00',
    fare: 28.00,
    distance_km: 65,
    operator: 'TNSTC-Salem'
  },
  {
    sl_no: 10,
    route_number: '44C',
    from_to: 'Salem New Bus Stand - Yercaud',
    via: 'Via Kannankurichi, Montfort',
    services: 6,
    journey_time: '1:30',
    fare: 22.00,
    distance_km: 32,
    operator: 'TNSTC-Salem'
  },
];

// Detailed stage information for Route 5 (Salem - Sankari)
const route5Stages: FareStage[] = [
  { stage_number: 1, stage_name: 'Salem New Bus Stand', distance_km: 0 },
  { stage_number: 2, stage_name: 'Hasthampatti', distance_km: 3 },
  { stage_number: 3, stage_name: 'Ammapet', distance_km: 7 },
  { stage_number: 4, stage_name: 'Gugai', distance_km: 12 },
  { stage_number: 5, stage_name: 'Kondalampatty', distance_km: 18 },
  { stage_number: 6, stage_name: 'Vanavasi', distance_km: 25 },
  { stage_number: 7, stage_name: 'Sankari', distance_km: 35 },
];

// Detailed stage information for Route 72 (Salem - Attur)
const route72Stages: FareStage[] = [
  { stage_number: 1, stage_name: 'Salem New Bus Stand', distance_km: 0 },
  { stage_number: 2, stage_name: 'Five Roads', distance_km: 4 },
  { stage_number: 3, stage_name: 'Omalur', distance_km: 15 },
  { stage_number: 4, stage_name: 'Thalaivasal', distance_km: 28 },
  { stage_number: 5, stage_name: 'Mecheri', distance_km: 42 },
  { stage_number: 6, stage_name: 'Gangavalli', distance_km: 52 },
  { stage_number: 7, stage_name: 'Attur', distance_km: 65 },
];

// Detailed stage information for Route 44C (Salem - Yercaud)
const route44CStages: FareStage[] = [
  { stage_number: 1, stage_name: 'Salem New Bus Stand', distance_km: 0 },
  { stage_number: 2, stage_name: 'Fairlands', distance_km: 3 },
  { stage_number: 3, stage_name: 'Kannankurichi', distance_km: 8 },
  { stage_number: 4, stage_name: 'Montfort School', distance_km: 15 },
  { stage_number: 5, stage_name: 'Yercaud Ghat Road', distance_km: 22 },
  { stage_number: 6, stage_name: 'Yercaud Lake', distance_km: 32 },
];

// Fare matrix for each route
export const salemFareMatrices: FareMatrix[] = [
  {
    route_id: 'route-5',
    base_fare: 5,
    fare_per_stage: 2.5,
    fare_per_km: 0.5,
    stages: route5Stages,
  },
  {
    route_id: 'route-72',
    base_fare: 8,
    fare_per_stage: 3.5,
    fare_per_km: 0.43,
    stages: route72Stages,
  },
  {
    route_id: 'route-44C',
    base_fare: 6,
    fare_per_stage: 3,
    fare_per_km: 0.69,
    stages: route44CStages,
  },
];

// Convert stages to stops with coordinates
const createStopsFromStages = (
  stages: FareStage[],
  routeId: string,
  baseCoords: { lat: number; lng: number },
  direction: 'north' | 'south' | 'east' | 'west'
): Stop[] => {
  return stages.map((stage, idx) => {
    // Calculate coordinates based on direction and distance
    let lat = baseCoords.lat;
    let lng = baseCoords.lng;
    
    const offset = stage.distance_km * 0.009; // Approximate: 1km ≈ 0.009 degrees
    
    if (direction === 'north') lat += offset;
    else if (direction === 'south') lat -= offset;
    else if (direction === 'east') lng += offset;
    else if (direction === 'west') lng -= offset;
    
    return {
      stop_id: `${routeId}-stop-${idx + 1}`,
      name: stage.stage_name,
      latitude: lat,
      longitude: lng,
      order: idx + 1,
      stage_number: stage.stage_number,
      zone: 'Salem',
      wheelchair: true,
      last_verified: new Date(),
    };
  });
};

// Create detailed routes with stops
export const salemDetailedRoutes: Route[] = [
  {
    route_id: 'route-5',
    route_name: 'Salem New Bus Stand - Sankari',
    route_number: '5',
    start_point: 'Salem New Bus Stand',
    end_point: 'Sankari',
    stops: createStopsFromStages(route5Stages, 'route-5', { lat: 11.6643, lng: 78.1460 }, 'west'),
    color: '#10b981',
    operator: 'TNSTC-Salem',
    via_notes: 'Via Ammapet, Gugai',
    route_type: 'city',
    frequency: '12 services daily',
    depot: 'Salem Town Depot',
    active: true,
    last_verified: new Date(),
  },
  {
    route_id: 'route-72',
    route_name: 'Salem New Bus Stand - Attur',
    route_number: '72',
    start_point: 'Salem New Bus Stand',
    end_point: 'Attur',
    stops: createStopsFromStages(route72Stages, 'route-72', { lat: 11.6643, lng: 78.1460 }, 'south'),
    color: '#f59e0b',
    operator: 'TNSTC-Salem',
    via_notes: 'Via Omalur, Thalaivasal',
    route_type: 'mofussil',
    frequency: '8 services daily',
    depot: 'Salem Central Depot',
    active: true,
    last_verified: new Date(),
  },
  {
    route_id: 'route-44C',
    route_name: 'Salem New Bus Stand - Yercaud',
    route_number: '44C',
    start_point: 'Salem New Bus Stand',
    end_point: 'Yercaud',
    stops: createStopsFromStages(route44CStages, 'route-44C', { lat: 11.6643, lng: 78.1460 }, 'east'),
    color: '#3b82f6',
    operator: 'TNSTC-Salem',
    via_notes: 'Via Kannankurichi, Montfort (Ghat Road)',
    route_type: 'ghat',
    frequency: '6 services daily',
    depot: 'Salem New Bus Stand',
    active: true,
    last_verified: new Date(),
  },
];

// Calculate fare between two stages
export const calculateStageFare = (
  routeId: string,
  fromStage: number,
  toStage: number
): number => {
  const fareMatrix = salemFareMatrices.find(fm => fm.route_id === routeId);
  if (!fareMatrix) return 0;

  const stageCount = Math.abs(toStage - fromStage);
  
  // Calculate based on stages
  const stageFare = fareMatrix.base_fare + (stageCount * fareMatrix.fare_per_stage);
  
  // Calculate based on distance if available
  let distanceFare = 0;
  if (fareMatrix.fare_per_km) {
    const fromStageData = fareMatrix.stages.find(s => s.stage_number === fromStage);
    const toStageData = fareMatrix.stages.find(s => s.stage_number === toStage);
    if (fromStageData && toStageData) {
      const distance = Math.abs(toStageData.distance_km - fromStageData.distance_km);
      distanceFare = fareMatrix.base_fare + (distance * fareMatrix.fare_per_km);
    }
  }
  
  // Return the higher of the two (TNSTC typically uses whichever is higher)
  return Math.max(stageFare, distanceFare);
};

// Get stage name by stage number
export const getStageName = (routeId: string, stageNumber: number): string => {
  const fareMatrix = salemFareMatrices.find(fm => fm.route_id === routeId);
  if (!fareMatrix) return `Stage ${stageNumber}`;
  
  const stage = fareMatrix.stages.find(s => s.stage_number === stageNumber);
  return stage ? stage.stage_name : `Stage ${stageNumber}`;
};
