import React, { useState } from 'react';
import { Upload, Download, Database, FileSpreadsheet, MapPin, Route as RouteIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner@2.0.3';
import { Route, Stop, RouteStopSequence } from '../types';

interface ImportStats {
  routes: number;
  stops: number;
  sequences: number;
}

export function DataImporter() {
  const [csvData, setCsvData] = useState({
    routes: '',
    stops: '',
    sequences: ''
  });
  const [importStats, setImportStats] = useState<ImportStats>({ routes: 0, stops: 0, sequences: 0 });
  const [error, setError] = useState<string>('');

  const parseCSV = (csvText: string): any[] => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const obj: any = {};
      headers.forEach((header, index) => {
        obj[header] = values[index];
      });
      data.push(obj);
    }

    return data;
  };

  const handleImportRoutes = () => {
    try {
      const routes = parseCSV(csvData.routes);
      if (routes.length === 0) {
        setError('No valid route data found');
        return;
      }

      // Validate required fields
      const requiredFields = ['route_id', 'name', 'operator', 'origin', 'destination'];
      const hasRequiredFields = requiredFields.every(field => 
        routes[0].hasOwnProperty(field)
      );

      if (!hasRequiredFields) {
        setError(`Missing required fields. Required: ${requiredFields.join(', ')}`);
        return;
      }

      setImportStats(prev => ({ ...prev, routes: routes.length }));
      toast.success(`Successfully imported ${routes.length} routes`);
      setError('');

      // In a real implementation, this would save to Supabase
      console.log('Imported routes:', routes);
    } catch (err) {
      setError('Error parsing CSV: ' + (err as Error).message);
    }
  };

  const handleImportStops = () => {
    try {
      const stops = parseCSV(csvData.stops);
      if (stops.length === 0) {
        setError('No valid stop data found');
        return;
      }

      const requiredFields = ['stop_id', 'stop_name', 'lat', 'lon'];
      const hasRequiredFields = requiredFields.every(field => 
        stops[0].hasOwnProperty(field)
      );

      if (!hasRequiredFields) {
        setError(`Missing required fields. Required: ${requiredFields.join(', ')}`);
        return;
      }

      setImportStats(prev => ({ ...prev, stops: stops.length }));
      toast.success(`Successfully imported ${stops.length} stops`);
      setError('');

      console.log('Imported stops:', stops);
    } catch (err) {
      setError('Error parsing CSV: ' + (err as Error).message);
    }
  };

  const handleImportSequences = () => {
    try {
      const sequences = parseCSV(csvData.sequences);
      if (sequences.length === 0) {
        setError('No valid sequence data found');
        return;
      }

      const requiredFields = ['route_id', 'stop_sequence', 'stop_id'];
      const hasRequiredFields = requiredFields.every(field => 
        sequences[0].hasOwnProperty(field)
      );

      if (!hasRequiredFields) {
        setError(`Missing required fields. Required: ${requiredFields.join(', ')}`);
        return;
      }

      setImportStats(prev => ({ ...prev, sequences: sequences.length }));
      toast.success(`Successfully imported ${sequences.length} route-stop sequences`);
      setError('');

      console.log('Imported sequences:', sequences);
    } catch (err) {
      setError('Error parsing CSV: ' + (err as Error).message);
    }
  };

  const downloadTemplate = (type: 'routes' | 'stops' | 'sequences') => {
    const templates = {
      routes: `route_id,name,operator,origin,destination,route_type,depot,last_verified
5,City Bus Stand - Kannankurichi,TNSTC Salem,Salem Central Bus Stand,Kannankurichi,city,Erumapalayam Depot,2025-10-21
72,City Bus Stand - Parappatti,TNSTC Salem,Salem Central Bus Stand,Parappatti,city,Vazhapadi Depot,2025-10-21`,
      stops: `stop_id,stop_name,lat,lon,zone,last_verified
SALM_STOP_001,Salem Central Bus Stand,11.6643,78.1460,Suramangalam,2025-10-21
SALM_STOP_002,Kannankurichi Bus Stop,11.6595,78.1502,Kannankurichi,2025-10-21`,
      sequences: `route_id,stop_sequence,stop_id
5,1,SALM_STOP_001
5,2,SALM_STOP_002
72,1,SALM_STOP_001`
    };

    const blob = new Blob([templates[type]], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_template.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${type} template`);
  };

  const exportCurrentData = () => {
    toast.info('Export functionality would export current database to CSV');
    // In real implementation, fetch from Supabase and convert to CSV
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="mb-2">Salem Bus Data Manager</h1>
          <p className="text-muted-foreground">
            Import CSV data for routes, stops, and route sequences
          </p>
        </div>
        <Button onClick={exportCurrentData} variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export Current Data
        </Button>
      </div>

      {/* Import Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <RouteIcon className="h-4 w-4" />
              Routes Imported
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{importStats.routes}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Stops Imported
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{importStats.stops}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Database className="h-4 w-4" />
              Sequences Imported
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{importStats.sequences}</div>
          </CardContent>
        </Card>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Import Tabs */}
      <Card>
        <CardHeader>
          <CardTitle>Import Data</CardTitle>
          <CardDescription>
            Paste CSV data or download templates to get started
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="routes">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="routes">Routes</TabsTrigger>
              <TabsTrigger value="stops">Stops</TabsTrigger>
              <TabsTrigger value="sequences">Sequences</TabsTrigger>
            </TabsList>

            <TabsContent value="routes" className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Format: route_id, name, operator, origin, destination, route_type, depot, last_verified
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => downloadTemplate('routes')}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Template
                </Button>
              </div>
              <Textarea
                placeholder="Paste routes CSV data here..."
                value={csvData.routes}
                onChange={(e) => setCsvData({ ...csvData, routes: e.target.value })}
                className="font-mono text-sm min-h-[200px]"
              />
              <Button onClick={handleImportRoutes}>
                <Upload className="mr-2 h-4 w-4" />
                Import Routes
              </Button>
            </TabsContent>

            <TabsContent value="stops" className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Format: stop_id, stop_name, lat, lon, zone, last_verified
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => downloadTemplate('stops')}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Template
                </Button>
              </div>
              <Textarea
                placeholder="Paste stops CSV data here..."
                value={csvData.stops}
                onChange={(e) => setCsvData({ ...csvData, stops: e.target.value })}
                className="font-mono text-sm min-h-[200px]"
              />
              <Button onClick={handleImportStops}>
                <Upload className="mr-2 h-4 w-4" />
                Import Stops
              </Button>
            </TabsContent>

            <TabsContent value="sequences" className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Format: route_id, stop_sequence, stop_id
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => downloadTemplate('sequences')}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Template
                </Button>
              </div>
              <Textarea
                placeholder="Paste route-stop sequences CSV data here..."
                value={csvData.sequences}
                onChange={(e) => setCsvData({ ...csvData, sequences: e.target.value })}
                className="font-mono text-sm min-h-[200px]"
              />
              <Button onClick={handleImportSequences}>
                <Upload className="mr-2 h-4 w-4" />
                Import Sequences
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Data Collection Guide</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="mb-2">Sources for Salem Data:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-2">
              <li>Salem District Transport page: <a href="https://salem.nic.in/departments/transport-department/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">salem.nic.in</a></li>
              <li>TNSTC Salem official PDFs and timetables</li>
              <li>OpenStreetMap (OSM) Overpass API for bus stops</li>
              <li>Field collection using GPS tracking apps (OSMTracker, GPX Logger)</li>
            </ul>
          </div>
          
          <div>
            <h3 className="mb-2">Next Steps:</h3>
            <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground ml-2">
              <li>Download the CSV templates above</li>
              <li>Collect route data from TNSTC website and local transport office</li>
              <li>Use OSM Overpass to extract existing bus stops in Salem</li>
              <li>Conduct field surveys to verify stop locations and names</li>
              <li>Import the collected data using the forms above</li>
              <li>Verify routes on the map view</li>
            </ol>
          </div>

          <div>
            <h3 className="mb-2">Python Scripts Available:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-2">
              <li>TNSTC web scraper (BeautifulSoup + requests)</li>
              <li>CSV to GeoJSON converter for route visualization</li>
              <li>Overpass API query for OSM bus stop extraction</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
